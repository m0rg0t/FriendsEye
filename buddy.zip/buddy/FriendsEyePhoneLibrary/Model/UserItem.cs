﻿using Buddy;
using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FriendsEyeAssists.Model
{
    public class UserItem: ViewModelBase
    {
        public UserItem()
        {
        }

        private string _userPassword = "";
        /// <summary>
        /// User password
        /// </summary>
        public string Password
        {
            get { return _userPassword; }
            set { 
                _userPassword = value;
                RaisePropertyChanged("Password");
            }
        }        

        private string _userName = "";
        /// <summary>
        /// User Login
        /// </summary>
        public string UserName
        {
            get { return _userName; }
            set { 
                _userName = value;
                RaisePropertyChanged("UserName");
            }
        }

        private int _age = 18;
        /// <summary>
        /// Users age
        /// </summary>
        public int Age
        {
            get { return _age; }
            set { 
                _age = value;
            }
        }

        private Uri _profilePicture;
        /// <summary>
        /// Profile image of this user
        /// </summary>
        public Uri ProfilePicture
        {
            get { return _profilePicture; }
            set { 
                _profilePicture = value;
                RaisePropertyChanged("ProfilePicture");
            }
        }

        private int _id;
        /// <summary>
        /// 
        /// </summary>
        public int ID
        {
            get { return _id; }
            set { _id = value;
            RaisePropertyChanged("ID");
            }
        }

        private string _ProfilePictureID;
        /// <summary>
        /// 
        /// </summary>
        public string ProfilePictureID
        {
            get { return _ProfilePictureID; }
            set { _ProfilePictureID = value; }
        }
        
        

        private AuthenticatedUser _buddyUser;
        /// <summary>
        /// buddy user item
        /// </summary>
        public AuthenticatedUser BuddyUser
        {
            get { return _buddyUser; }
            set { 
                _buddyUser = value;
                this.Age = this._buddyUser.Age;
                this.Email = this._buddyUser.Email.ToString();
                this.ID = this.BuddyUser.ID;
                this.ProfilePicture = this.BuddyUser.ProfilePicture;
                this.ProfilePictureID = this.BuddyUser.ProfilePictureID;
                RaisePropertyChanged("BuddyUser");
            }
        }

        private string _email;
        /// <summary>
        /// user email
        /// </summary>
        public string Email
        {
            get { return _email; }
            set { 
                _email = value;
                RaisePropertyChanged("Email");
            }
        }
        
        
    }
}
